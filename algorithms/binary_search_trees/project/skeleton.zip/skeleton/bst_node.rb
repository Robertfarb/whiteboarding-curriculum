class BSTNode
  def initialize
  end
end
