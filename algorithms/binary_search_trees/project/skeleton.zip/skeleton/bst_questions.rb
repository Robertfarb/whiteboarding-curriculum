# *NB*: what do you need to require here? This is a good chance to review a little Ruby require syntax.

def kth_largest(bst, k)
end

def lowest_common_ancestor(node1, node2)
end

def post_order_traversal(bst)
end

def reconstruct(post_order, in_order)
end
