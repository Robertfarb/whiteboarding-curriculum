class BinarySearchTree
  def initialize
  end

  def find(el)
  end

  def insert(el)
  end

  def delete(el)
  end

  def is_balanced?
  end

  def in_order_traversal
  end

  def maximum
  end

  def depth
  end 
end
